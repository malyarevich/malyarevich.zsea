﻿namespace AILabs.TicTacToe.Core.Models
{
    public enum CellType
    {
        Cross, Nought, Empty
    }
}