﻿namespace AILabs.Packer.Core.Models
{
    public static class PhysicConstants
    {
        public const double Gravity = 9.8;

        public const double Friction = 0.3;
    }
}