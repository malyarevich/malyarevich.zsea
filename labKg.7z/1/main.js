(function () {
  var canvas = document.getElementById('canvas'),
    ctx = canvas.getContext('2d'),
    startButton = document.getElementById('start'),
    clearButton = document.getElementById('clear'),
    fillColor = 'red',
    points = [];

  function drawPoint(x, y) {
    ctx.fillStyle = fillColor;
    ctx.fillRect(x, y, 1, 1);
  }
  function draw() {
    var i = 0,
      currentPoint,
      nextPoint,
      steep,
      x,
      y,
      x0,
      y0,
      x1,
      y1,
      dx,
      dy,
      err,
      ystep;

    for (i = 0; i < points.length - 1; i++) { //for every line
      currentPoint = points[i];
      nextPoint = points[i + 1];
      x0 = currentPoint.x;
      y0 = currentPoint.y;
      x1 = nextPoint.x;
      y1 = nextPoint.y;

      // algorythm start
      steep = Math.abs(y1 - y0) > Math.abs(x1 - x0); // быстрый рост по у
      if (steep) {
        x0 = [y0, y0 = x0][0];
        x1 = [y1, y1 = x1][0];
      }
      if (x0 > x1) {
        x0 = [x1, x1 = x0][0];
        y0 = [y1, y1 = y0][0];
      }
      dx = x1 - x0;
      dy = Math.abs(y1 - y0);
      err = dx / 2; // Здесь используется оптимизация с умножением на dx, чтобы избавиться от лишних дробей
      ystep = (y0 < y1) ? 1 : -1; // Выбираем направление роста координаты y
      y = y0;
      for (x = x0; x < x1; x++) {
        drawPoint(steep ? y : x, steep ? x : y); // вернуть координаты на место, если был поворот
        err -= dy;
        if (err < 0) {
          y += ystep;
          err += dx;
        }
      }
    }
    ctx.stroke();
  }
  function addPoint(x, y) {
    drawPoint(x, y);
    points.splice(points.length, 0, {'x' : x, 'y' : y});
  }
  function clear() {
    points = [];
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  canvas.onclick = function (e) {
    var x = 0,
      y = 0;
    //get click point
    if (e.pageX || e.pageY) {
      x = e.pageX;
      y = e.pageY;
    } else {
      x = e.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
      y = e.clientY + document.body.scrollTop + document.documentElement.scrollTop;
    }
    x -= canvas.offsetLeft;
    y -= canvas.offsetTop;

    //collect click point
    addPoint(x, y);
  };

  startButton.onclick = draw;
  clearButton.onclick = clear;
}());
